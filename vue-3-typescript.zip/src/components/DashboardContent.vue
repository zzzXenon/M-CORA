<template>
  <template v-if="selectedMachine">
    <HeadlineSection
      :totalCO2="currentMetrics.totalCO2"
      :netImpact="currentMetrics.netImpact"
    />

    <RealtimeSection
      :co2PerHour="currentMetrics.co2PerHour"
      :mineralOutput="currentMetrics.mineralOutput"
      :mineralTarget="currentMetrics.mineralTarget"
      :efficiencyScore="currentMetrics.efficiencyScore"
      :efficiencyStatus="currentMetrics.efficiencyStatus"
      :efficiencyTrend="currentMetrics.efficiencyTrend"
    />

    <CumulativeSection
      :totalCO2="currentMetrics.totalCO2"
      :co2HistoryData="co2HistoryData"
      :co2Stats="co2Stats"
    />

    <HardwareSection
      :unitId="selectedMachine.id"
      :location="selectedMachine.location"
    />
  </template>
</template>

<script setup lang="ts">
import HeadlineSection from './sections/HeadlineSection.vue';
import RealtimeSection from './sections/RealtimeSection.vue';
import CumulativeSection from './sections/CumulativeSection.vue';
import HardwareSection from './sections/HardwareSection.vue';
import type { Machine, DashboardMetrics, CO2DayData } from '../types/index';

interface Props {
  selectedMachine: Machine | undefined;
  currentMetrics: DashboardMetrics;
  co2HistoryData: CO2DayData[];
  co2Stats: {
    min: number;
    max: number;
    avg: number;
  };
}

defineProps<Props>();
</script>
