<template>
  <Teleport to="body">
    <div
      v-if="isOpen"
      class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      @click.self="closeModal"
    >
      <div class="bg-white dark:bg-slate-900 rounded-xl shadow-lg w-full max-w-md p-6">
        <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4">
          {{ isRenaming ? 'Rename Machine' : 'Add New Machine' }}
        </h3>

        <form @submit.prevent="handleSubmit" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">
              Machine Name
            </label>
            <input
              v-model="formData.name"
              type="text"
              required
              class="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              placeholder="e.g., Albatross-1"
            />
          </div>

          <div v-if="!isRenaming">
            <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">
              Machine ID
            </label>
            <input
              v-model="formData.id"
              type="text"
              required
              class="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              placeholder="e.g., CRC-001A"
            />
          </div>

          <div class="flex gap-3 pt-4">
            <button
              type="button"
              @click="closeModal"
              class="flex-1 px-4 py-2 text-sm font-medium text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-800 rounded-lg hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              class="flex-1 px-4 py-2 text-sm font-medium text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors"
            >
              {{ isRenaming ? 'Rename' : 'Add Machine' }}
            </button>
          </div>
        </form>

        <div v-if="error" class="mt-4 p-3 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded-lg text-sm">
          {{ error }}
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';

interface Props {
  isOpen: boolean;
  isRenaming?: boolean;
  machineId?: string;
  initialName?: string;
}

interface Emits {
  (e: 'close'): void;
  (e: 'submit', data: { name: string; id?: string }): void;
}

const props = withDefaults(defineProps<Props>(), {
  isRenaming: false,
});

defineEmits<Emits>();

const formData = reactive({ name: '', id: '' });
const error = ref('');

const handleSubmit = () => {
  error.value = '';
  if (!formData.name.trim()) {
    error.value = 'Machine name is required';
    return;
  }
  if (!props.isRenaming && !formData.id.trim()) {
    error.value = 'Machine ID is required';
    return;
  }
  // Emit handled by parent
};

const closeModal = () => {
  error.value = '';
  formData.name = '';
  formData.id = '';
};
</script>
