<template>
  <div class="flex flex-col h-full bg-slate-900 text-slate-100 transition-all duration-300"
       :class="{ 'w-64': isExpanded, 'w-20': !isExpanded }">
    
    <!-- Header with Toggle -->
    <div class="flex items-center justify-between p-4 border-b border-slate-700">
      <h1 v-if="isExpanded" class="text-lg font-bold text-white truncate">
        TerraCapture
      </h1>
      <button
        @click="isExpanded = !isExpanded"
        class="p-2 hover:bg-slate-800 rounded-lg transition-colors"
        :aria-label="isExpanded ? 'Collapse sidebar' : 'Expand sidebar'"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            :d="isExpanded ? 'M15 19l-7-7 7-7' : 'M9 5l7 7-7 7'" />
        </svg>
      </button>
    </div>

    <!-- Navigation Content -->
    <nav class="flex-grow overflow-y-auto p-4">
      <!-- Add Machine Button -->
      <button
        @click="openAddModal"
        class="w-full mb-6 px-4 py-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors"
        :class="{ 'px-2': !isExpanded }"
      >
        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
        </svg>
        <span v-if="isExpanded">Add Machine</span>
      </button>

      <!-- Machine List -->
      <div class="space-y-2">
        <div v-for="machine in machines" :key="machine.id" class="group">
          <button
            @click="selectMachine(machine.id)"
            :class="[
              'w-full p-3 rounded-lg transition-colors text-left flex items-center justify-between gap-2',
              selectedMachineId === machine.id
                ? 'bg-teal-600 text-white'
                : 'text-slate-300 hover:bg-slate-800'
            ]"
          >
            <span v-if="isExpanded" class="truncate text-sm font-medium">
              {{ machine.name }}
            </span>
            <svg v-else class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 5a2 2 0 00-2 2v12a2 2 0 002 2h6a2 2 0 002-2V7a2 2 0 00-2-2m-6 0a2 2 0 002 2h6a2 2 0 012 2v12a2 2 0 01-2 2m0 0H9m6 0h6" />
            </svg>
            <button
              v-if="isExpanded"
              @click.stop="toggleMachineMenu(machine.id)"
              class="p-1 rounded hover:bg-slate-700 transition-colors"
            >
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </button>

          <!-- Machine Actions Dropdown -->
          <div
            v-if="isExpanded && expandedMachineId === machine.id"
            class="ml-2 mt-1 space-y-1 bg-slate-800 rounded-lg p-2"
          >
            <button
              @click="openRenameModal(machine.id, machine.name)"
              class="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 rounded flex items-center gap-2 transition-colors"
            >
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
              Rename
            </button>
            <button
              @click="deleteMachine(machine.id)"
              class="w-full text-left px-3 py-2 text-sm text-red-400 hover:bg-red-900/30 rounded flex items-center gap-2 transition-colors"
            >
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Delete
            </button>
          </div>
        </div>
      </div>
    </nav>

    <!-- Auth Section -->
    <div class="border-t border-slate-700 p-4">
      <button
        v-if="isExpanded"
        class="w-full px-4 py-2 text-sm bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors"
      >
        Logout
      </button>
      <button
        v-else
        class="w-full p-2 text-slate-300 hover:bg-slate-800 rounded-lg transition-colors"
        title="Logout"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
        </svg>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

interface Props {
  machines: any[];
  selectedMachineId: string | null;
}

interface Emits {
  (e: 'select-machine', id: string): void;
  (e: 'open-add-modal'): void;
  (e: 'open-rename-modal', id: string, name: string): void;
  (e: 'delete-machine', id: string): void;
}

defineProps<Props>();
defineEmits<Emits>();

const isExpanded = ref(true);
const expandedMachineId = ref<string | null>(null);

const toggleMachineMenu = (machineId: string) => {
  expandedMachineId.value = expandedMachineId.value === machineId ? null : machineId;
};

const selectMachine = (machineId: string) => {
  // Implementation handled via event emit
};

const openAddModal = () => {
  // Implementation handled via event emit
};

const openRenameModal = (id: string, name: string) => {
  // Implementation handled via event emit
};

const deleteMachine = (id: string) => {
  // Implementation handled via event emit
};
</script>
