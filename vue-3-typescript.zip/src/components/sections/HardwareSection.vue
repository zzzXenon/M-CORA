<template>
  <section>
    <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Hardware Information</h3>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <!-- Unit Information -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="mb-6">
          <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-2">Unit ID</div>
          <div class="text-2xl font-mono font-bold text-gray-900 dark:text-white break-all">
            {{ unitId }}
          </div>
        </div>
        
        <div>
          <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-2">Status</div>
          <div class="flex items-center gap-2">
            <span class="inline-block w-2 h-2 bg-green-500 rounded-full"></span>
            <span class="text-lg font-bold text-green-600 dark:text-green-400">Online / Stable</span>
          </div>
        </div>
      </div>

      <!-- Location Map Placeholder -->
      <div class="bg-gradient-to-br from-gray-100 to-gray-200 dark:from-slate-700 dark:to-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700 flex items-center justify-center min-h-48">
        <div class="text-center">
          <svg class="w-12 h-12 mx-auto mb-3 text-gray-400 dark:text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 003 16.382V5.618a1 1 0 01.553-.894l5.447-2.724a2 2 0 011.894 0l5.447 2.724A1 1 0 0121 5.618v10.764a1 1 0 01-.553.894l-5.447 2.724a2 2 0 01-1.894 0z" />
          </svg>
          <p class="text-gray-600 dark:text-slate-400 font-medium">{{ location }}</p>
          <p class="text-xs text-gray-500 dark:text-slate-500 mt-1">Map Integration Coming Soon</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
interface Props {
  unitId: string;
  location: string;
}

defineProps<Props>();
</script>
