<template>
  <section class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
    <!-- Total CO2 Credit -->
    <div class="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
      <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-2">Total CO2 Credit</div>
      <div class="text-5xl font-bold text-teal-600 dark:text-teal-400 mb-1">
        {{ totalCO2.toFixed(1) }}
      </div>
      <div class="text-lg text-gray-600 dark:text-slate-400 font-medium">
        tonnes (T)
      </div>
    </div>

    <!-- Net Carbon Impact -->
    <div
      :class="[
        'bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border-l-4',
        netImpact >= 0
          ? 'border-green-500 dark:border-green-400'
          : 'border-red-500 dark:border-red-400'
      ]"
    >
      <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-2">
        Net Carbon Impact
      </div>
      <div
        :class="[
          'text-3xl font-bold mb-1',
          netImpact >= 0
            ? 'text-green-600 dark:text-green-400'
            : 'text-red-600 dark:text-red-400'
        ]"
      >
        {{ netImpact >= 0 ? '+' : '' }}{{ netImpact.toFixed(2) }}
      </div>
      <div class="text-base text-gray-600 dark:text-slate-400 font-medium">
        T (removed vs. used)
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
interface Props {
  totalCO2: number;
  netImpact: number;
}

defineProps<Props>();
</script>
