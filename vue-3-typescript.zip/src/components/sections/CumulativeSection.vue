<template>
  <section class="mb-8">
    <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Cumulative Output</h3>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      <!-- Total Green Material -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="flex items-start gap-3">
          <svg class="w-8 h-8 text-green-600 dark:text-green-400 mt-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">
              {{ (totalCO2 * 0.8).toFixed(0) }}T
            </div>
            <div class="text-sm text-gray-600 dark:text-slate-400">Green Material Harvested</div>
          </div>
        </div>
      </div>

      <!-- Total Hydrogen Produced -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="flex items-start gap-3">
          <svg class="w-8 h-8 text-blue-600 dark:text-blue-400 mt-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">
              {{ (totalCO2 * 0.05).toFixed(0) }}kg
            </div>
            <div class="text-sm text-gray-600 dark:text-slate-400">Hydrogen Produced</div>
          </div>
        </div>
      </div>

      <!-- CO2 Stats Min -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-2">Daily Minimum</div>
        <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ co2Stats.min.toFixed(1) }}T</div>
        <div class="text-xs text-gray-600 dark:text-slate-400 mt-1">30-day period</div>
      </div>

      <!-- CO2 Stats Avg -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-2">Daily Average</div>
        <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ co2Stats.avg.toFixed(1) }}T</div>
        <div class="text-xs text-gray-600 dark:text-slate-400 mt-1">30-day period</div>
      </div>
    </div>

    <!-- 30-Day CO2 Chart -->
    <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
      <div class="flex items-center justify-between mb-4">
        <h4 class="text-sm font-semibold text-gray-900 dark:text-white">CO2 Removed (Last 30 Days)</h4>
        <div class="text-xs text-gray-600 dark:text-slate-400">
          Peak: {{ co2Stats.max.toFixed(1) }}T
        </div>
      </div>
      
      <!-- Chart -->
      <svg viewBox="0 0 800 200" class="w-full h-48" preserveAspectRatio="none">
        <!-- Grid -->
        <line x1="0" y1="150" x2="800" y2="150" stroke="#e5e7eb" stroke-width="1" class="dark:stroke-slate-700" />
        
        <!-- Area Fill -->
        <defs>
          <linearGradient id="co2Gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#0d9488" stop-opacity="0.3" />
            <stop offset="100%" stop-color="#0d9488" stop-opacity="0" />
          </linearGradient>
        </defs>
        
        <!-- Data Area -->
        <polygon
          :points="areaPoints"
          fill="url(#co2Gradient)"
          class="dark:fill-teal-500/20"
        />
        
        <!-- Data Line -->
        <polyline
          :points="linePoints"
          fill="none"
          stroke="#0d9488"
          stroke-width="2"
          class="dark:stroke-teal-400"
        />
        
        <!-- Data Points -->
        <circle
          v-for="(point, idx) in chartDataPoints"
          :key="idx"
          :cx="point.x"
          :cy="point.y"
          r="3"
          fill="#0d9488"
          class="dark:fill-teal-400"
        />
        
        <!-- Axis Labels -->
        <text x="10" y="175" font-size="12" fill="#9ca3af" class="dark:fill-slate-400">Day 1</text>
        <text x="760" y="175" font-size="12" fill="#9ca3af" text-anchor="end" class="dark:fill-slate-400">Day 30</text>
      </svg>
    </div>
  </section>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import type { CO2DayData } from '../../types/index';

interface Props {
  totalCO2: number;
  co2HistoryData: CO2DayData[];
  co2Stats: {
    min: number;
    max: number;
    avg: number;
  };
}

const props = defineProps<Props>();

const chartDataPoints = computed(() => {
  const { data } = computeChartPoints();
  return data;
});

const linePoints = computed(() => {
  const { points } = computeChartPoints();
  return points;
});

const areaPoints = computed(() => {
  const { points } = computeChartPoints();
  return points + ' 800,150 0,150';
});

const computeChartPoints = () => {
  const width = 800;
  const height = 150;
  const padding = 0;
  
  const values = props.co2HistoryData.map(d => d.co2Removed);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  const range = maxValue - minValue || 1;
  
  const points = props.co2HistoryData.map((d, idx) => {
    const x = (idx / (props.co2HistoryData.length - 1)) * width;
    const normalized = (d.co2Removed - minValue) / range;
    const y = height - normalized * height;
    return `${x},${y}`;
  }).join(' ');

  const data = props.co2HistoryData.map((d, idx) => {
    const x = (idx / (props.co2HistoryData.length - 1)) * width;
    const normalized = (d.co2Removed - minValue) / range;
    const y = height - normalized * height;
    return { x, y };
  });

  return { points, data };
};
</script>
