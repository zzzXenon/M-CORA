<template>
  <section class="mb-8">
    <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Real-Time Performance</h3>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <!-- CO2 Captured per Hour -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-4">
          CO2 Captured per Hour
        </div>
        <div class="flex items-center justify-between mb-4">
          <div class="text-4xl font-bold text-blue-600 dark:text-blue-400">
            {{ co2PerHour.toFixed(2) }}
          </div>
          <div class="text-xs font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-400 px-3 py-1 rounded-full">
            T/h
          </div>
        </div>
        <p class="text-xs text-gray-600 dark:text-slate-400">
          vs. last hour: <span class="font-bold text-green-600 dark:text-green-400">+3.1%</span>
        </p>
        <!-- Mini Sparkline -->
        <div class="h-10 mt-4 flex gap-1 items-end">
          <div
            v-for="(h, idx) in sparklineData"
            :key="idx"
            :style="{ height: h + '%' }"
            class="flex-1 bg-blue-400 dark:bg-blue-500 rounded-sm"
          />
        </div>
      </div>

      <!-- Mineral Output Progress -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-4">
          Mineral Output Progress
        </div>
        <div class="flex items-center justify-between mb-4">
          <div class="text-4xl font-bold text-amber-600 dark:text-amber-400">
            {{ mineralOutput.toFixed(0) }}
          </div>
          <div class="text-xs font-medium bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400 px-3 py-1 rounded-full">
            tonnes/day
          </div>
        </div>
        <p class="text-xs text-gray-600 dark:text-slate-400 mb-2">
          Daily Target: {{ mineralTarget }} tonnes
        </p>
        <!-- Progress Bar -->
        <div class="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2">
          <div
            :style="{ width: mineralProgress + '%' }"
            class="bg-amber-500 dark:bg-amber-400 h-2 rounded-full transition-all duration-500"
          />
        </div>
        <p class="text-xs text-gray-600 dark:text-slate-400 mt-2 text-right">
          {{ mineralProgress.toFixed(0) }}% complete
        </p>
      </div>

      <!-- Energy Efficiency AI -->
      <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
        <div class="text-sm font-semibold text-gray-600 dark:text-slate-400 mb-4">
          Energy Efficiency AI
        </div>
        <div class="flex items-center justify-between gap-6">
          <div class="flex-1">
            <div class="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {{ efficiencyScore.toFixed(1) }}%
            </div>
            <div
              :class="[
                'text-xs font-medium px-2 py-1 rounded-full inline-block',
                efficiencyStatus === 'optimal'
                  ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400'
                  : efficiencyStatus === 'degrading'
                  ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400'
                  : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
              ]"
            >
              {{ efficiencyStatus.charAt(0).toUpperCase() + efficiencyStatus.slice(1) }}
            </div>
            <p class="text-xs text-gray-600 dark:text-slate-400 mt-2">
              {{ efficiencyTrend >= 0 ? '↑' : '↓' }} {{ Math.abs(efficiencyTrend).toFixed(1) }}% trend
            </p>
          </div>
          <!-- Circular Progress -->
          <svg class="w-20 h-20 flex-shrink-0" viewBox="0 0 80 80">
            <circle cx="40" cy="40" r="30" class="fill-none stroke-gray-200 dark:stroke-slate-700" stroke-width="5" />
            <circle
              cx="40"
              cy="40"
              r="30"
              class="fill-none stroke-teal-500 dark:stroke-teal-400 transition-all duration-500"
              stroke-width="5"
              stroke-linecap="round"
              :style="{
                strokeDasharray: `${(efficiencyScore / 100) * (2 * Math.PI * 30)} ${2 * Math.PI * 30}`,
                transform: 'rotate(-90deg)',
                transformOrigin: '40px 40px'
              }"
            />
          </svg>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { computed } from 'vue';

interface Props {
  co2PerHour: number;
  mineralOutput: number;
  mineralTarget: number;
  efficiencyScore: number;
  efficiencyStatus: 'optimal' | 'degrading' | 'critical';
  efficiencyTrend: number;
}

const props = defineProps<Props>();

const mineralProgress = computed(() => {
  return (props.mineralOutput / props.mineralTarget) * 100;
});

const sparklineData = computed(() => {
  const data = [];
  for (let i = 0; i < 12; i++) {
    data.push(Math.random() * 80 + 20);
  }
  return data;
});
</script>
