import { reactive, computed } from "vue"
import type { DashboardMetrics, CO2DayData } from "../types/index"

export function useDashboardData() {
  const metricsMap: Record<string, DashboardMetrics> = {
    "CRC-001A": {
      totalCO2: 1254.7,
      carbonUsed: 231.2,
      netImpact: 1254.7 - 231.2,
      co2PerHour: 1.57,
      mineralOutput: 185,
      mineralTarget: 250,
      efficiencyScore: 92.4,
      efficiencyStatus: "optimal",
      efficiencyTrend: 3.2,
    },
    "CRC-002Z": {
      totalCO2: 876.3,
      carbonUsed: 190.5,
      netImpact: 876.3 - 190.5,
      co2PerHour: 0.98,
      mineralOutput: 210,
      mineralTarget: 280,
      efficiencyScore: 85.1,
      efficiencyStatus: "degrading",
      efficiencyTrend: -1.5,
    },
  }

  const generateCO2History = (): CO2DayData[] => {
    const data: CO2DayData[] = []
    for (let i = 1; i <= 30; i++) {
      const baseValue = 35 + Math.random() * 25
      const trend = i > 15 ? 5 : 0
      data.push({
        day: i,
        date: `Day ${i}`,
        co2Removed: baseValue + trend + (Math.random() - 0.5) * 10,
      })
    }
    return data
  }

  const currentMetrics = reactive<DashboardMetrics>(metricsMap["CRC-001A"])

  const co2HistoryData = reactive<CO2DayData[]>(generateCO2History())

  const mineralProgress = computed(() => {
    return (currentMetrics.mineralOutput / currentMetrics.mineralTarget) * 100
  })

  const updateMetricsForMachine = (machineId: string) => {
    const metrics = metricsMap[machineId]
    if (metrics) {
      Object.assign(currentMetrics, metrics)
    }
  }

  const co2Stats = computed(() => {
    const values = co2HistoryData.map((d) => d.co2Removed)
    return {
      min: Math.min(...values),
      max: Math.max(...values),
      avg: values.reduce((a, b) => a + b) / values.length,
    }
  })

  return {
    currentMetrics,
    co2HistoryData,
    mineralProgress,
    co2Stats,
    updateMetricsForMachine,
  }
}
