import { ref, computed } from "vue"
import type { Machine } from "../types/index"

export function useMachines() {
  const machines = ref<Machine[]>([
    { id: "CRC-001A", name: "Albatross-1", location: "Iceland" },
    { id: "CRC-002Z", name: "Zephyr-2", location: "Texas, USA" },
  ])

  const selectedMachineId = ref<string | null>(machines.value.length > 0 ? machines.value[0].id : null)

  const selectedMachine = computed(() => machines.value.find((m) => m.id === selectedMachineId.value))

  const selectMachine = (id: string) => {
    selectedMachineId.value = id
  }

  const addMachine = (name: string, id: string, location = "Newly Added") => {
    if (!name.trim() || !id.trim()) {
      throw new Error("Machine Name and ID are required")
    }

    if (machines.value.some((m) => m.id === id)) {
      throw new Error("Machine ID already exists")
    }

    const newMachine: Machine = { id, name, location }
    machines.value.push(newMachine)
    selectMachine(id)
    return newMachine
  }

  const renameMachine = (id: string, newName: string) => {
    const machine = machines.value.find((m) => m.id === id)
    if (machine) {
      machine.name = newName
    }
  }

  const deleteMachine = (id: string) => {
    const index = machines.value.findIndex((m) => m.id === id)
    if (index !== -1) {
      machines.value.splice(index, 1)
      if (selectedMachineId.value === id && machines.value.length > 0) {
        selectMachine(machines.value[0].id)
      }
    }
  }

  return {
    machines,
    selectedMachineId,
    selectedMachine,
    selectMachine,
    addMachine,
    renameMachine,
    deleteMachine,
  }
}
