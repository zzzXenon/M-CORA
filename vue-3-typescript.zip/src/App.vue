<template>
  <div class="flex min-h-screen bg-gray-50 dark:bg-slate-900">
    <!-- Sidebar -->
    <Sidebar
      :machines="machines"
      :selectedMachineId="selectedMachineId"
      @select-machine="selectMachine"
      @open-add-modal="() => (isAddModalOpen = true)"
      @open-rename-modal="(id, name) => openRenameModal(id, name)"
      @delete-machine="deleteMachine"
    />

    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
      <div class="p-6 md:p-8 max-w-7xl mx-auto">
        <!-- Header -->
        <header class="mb-8">
          <h1 class="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-2">
            {{ dashboardTitle }}
          </h1>
          <p class="text-gray-600 dark:text-slate-400">Real-time and cumulative carbon metrics.</p>
        </header>

        <!-- Dashboard Sections -->
        <DashboardContent
          :selectedMachine="selectedMachine"
          :currentMetrics="currentMetrics"
          :co2HistoryData="co2HistoryData"
          :co2Stats="co2Stats"
        />
      </div>
    </main>

    <!-- Modals -->
    <MachineModal
      :isOpen="isAddModalOpen"
      :isRenaming="false"
      @close="isAddModalOpen = false"
      @submit="handleAddMachine"
    />

    <MachineModal
      :isOpen="isRenameModalOpen"
      :isRenaming="true"
      :machineId="renameMachineId"
      :initialName="renameMachineName"
      @close="isRenameModalOpen = false"
      @submit="handleRenameMachine"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, watch, computed } from 'vue';
import Sidebar from './components/Sidebar.vue';
import MachineModal from './components/MachineModal.vue';
import DashboardContent from './components/DashboardContent.vue';
import { useMachines } from './composables/useMachines';
import { useDashboardData } from './composables/useDashboardData';

const { machines, selectedMachineId, selectedMachine, selectMachine, addMachine, renameMachine, deleteMachine } = useMachines();
const { currentMetrics, co2HistoryData, co2Stats, updateMetricsForMachine } = useDashboardData();

const isAddModalOpen = ref(false);
const isRenameModalOpen = ref(false);
const renameMachineId = ref<string | null>(null);
const renameMachineName = ref('');

const dashboardTitle = computed(() => {
  return selectedMachine.value?.name 
    ? `Dashboard: ${selectedMachine.value.name}`
    : 'Dashboard: Select a Machine';
});

const handleAddMachine = (data: { name: string; id: string }) => {
  try {
    addMachine(data.name, data.id);
    isAddModalOpen.value = false;
    updateMetricsForMachine(data.id);
  } catch (error) {
    console.error(error);
  }
};

const handleRenameMachine = (data: { name: string }) => {
  if (renameMachineId.value) {
    renameMachine(renameMachineId.value, data.name);
    isRenameModalOpen.value = false;
  }
};

const openRenameModal = (id: string, name: string) => {
  renameMachineId.value = id;
  renameMachineName.value = name;
  isRenameModalOpen.value = true;
};

watch(selectedMachineId, (newId) => {
  if (newId) {
    updateMetricsForMachine(newId);
  }
});
</script>
