export interface Machine {
  id: string
  name: string
  location: string
}

export interface DashboardMetrics {
  totalCO2: number
  carbonUsed: number
  netImpact: number
  co2PerHour: number
  mineralOutput: number
  mineralTarget: number
  efficiencyScore: number
  efficiencyStatus: "optimal" | "degrading" | "critical"
  efficiencyTrend: number // percentage change
}

export interface CO2DayData {
  day: number
  date: string
  co2Removed: number
}

export interface DashboardState {
  machines: Machine[]
  selectedMachineId: string | null
  metrics: DashboardMetrics
  co2HistoryData: CO2DayData[]
}
